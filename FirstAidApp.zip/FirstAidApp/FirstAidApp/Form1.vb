﻿Public Class Form1
    Dim question(0 To 6) As String
    Dim ans1(0 To 6) As String
    Dim ans2(0 To 6) As String
    Dim ans3(0 To 6) As String
    Dim ans4(0 To 6) As String
    Dim realans(0 To 6) As Char
    Dim myanswer As Char
    Dim qnumber As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        TabControl1.SelectTab(3)
        TabControl2.Visible = False
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click

        TabControl1.SelectTab(0)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        TabControl1.SelectTab(4)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        qnumber = 0

        'Question 1
        question(0) = "Who should you check the personal safety of first?"
        'Question 1's 4 possible answers
        ans1(0) = "The casualty"
        ans2(0) = "Yourself"
        ans3(0) = "The holby city"
        ans4(0) = "Thomas Jefferson" & vbCrLf & ""
        'Question 1's real answer
        realans(0) = "B"

        'Question 2
        question(1) = "What should you do if the casualty doesn't respond?"
        ans1(1) = "Punch them someplace."
        ans2(1) = "Slap them awake"
        ans3(1) = "Send for help"
        ans4(1) = "Build a house"
        realans(1) = "C"

        'Question 3
        question(2) = "What 3 things should you do to check for normal breathing?"
        ans1(2) = "Look, listen and feel"
        ans2(2) = "Stop, drop and roll"
        ans3(2) = "McGann hurt Ecclestone"
        ans4(2) = "Lick your finger and stick it in the" & vbCrLf & "air"
        realans(2) = "A"

        'Question 4
        question(3) = "What should you do if a casualty's breathing is abnormal?"
        ans1(3) = "Shakespeare"
        ans2(3) = "Oxygen pump to the face"
        ans3(3) = "CPR"
        ans4(3) = "Get a shovel, a van and your" & vbCrLf & "closest friend..."
        realans(3) = "C"

        'Question 5
        question(4) = "During CPR, how many chest compressions should you do?"
        ans1(4) = "Over 9000"
        ans2(4) = "100"
        ans3(4) = "Trick question, you can't compress" & vbCrLf & "a chest!"
        ans4(4) = "4815162342"
        realans(4) = "B"

        'Question 6
        question(5) = "Which half of the casualty's chest should you compress?"
        ans1(5) = "Lower"
        ans2(5) = "Upper"
        ans3(5) = "Middle"
        ans4(5) = "I'm telling you, you can't" & vbCrLf & "compress a chest!"
        realans(5) = "A"

        'Question 7
        question(6) = "What should you do if a defibrilator isn't available?"
        ans1(6) = "Continue doing CPR"
        ans2(6) = "Phone a friend"
        ans3(6) = "Order a pizza"
        ans4(6) = "Get a shovel, a van and your" & vbCrLf & "closest friend..."
        realans(6) = "C"

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        TabControl1.SelectTab(1)

        qnumber = 1
        TextBox4.Text = question(qnumber - 1)
        RadioButton1.Text = ans1(qnumber - 1)
        RadioButton2.Text = ans2(qnumber - 1)
        RadioButton3.Text = ans3(qnumber - 1)
        RadioButton4.Text = ans4(qnumber - 1)
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click

        If RadioButton1.Checked = True Then
            myanswer = "A"
        ElseIf RadioButton2.Checked = True Then
            myanswer = "B"
        ElseIf RadioButton3.Checked = True Then
            myanswer = "C"
        ElseIf RadioButton4.Checked = True Then
            myanswer = "D"
        End If


        If myanswer = realans(qnumber - 1) Then
            Label25.Text = Val(Label25.Text) + 1
        Else
            Label27.Text = Val(Label27.Text) + 1
        End If

        GroupBox2.Text = "Question " & qnumber & ":"

        If qnumber = 7 Then
            TabControl1.SelectTab(2)
            TextBox5.Text = Val(Label25.Text) & " / " & "7"
        Else
            qnumber = qnumber + 1
            TextBox4.Text = question(qnumber - 1)
            RadioButton1.Text = ans1(qnumber - 1)
            RadioButton2.Text = ans2(qnumber - 1)
            RadioButton3.Text = ans3(qnumber - 1)
            RadioButton4.Text = ans4(qnumber - 1)
        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        TabControl2.Visible = True
        TabControl2.SelectTab(0)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        TabControl2.Visible = True
        TabControl2.SelectTab(1)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click

        TabControl2.Visible = True
        TabControl2.SelectTab(2)
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click

        TabControl2.Visible = True
        TabControl2.SelectTab(3)
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click

        TabControl2.Visible = True
        TabControl2.SelectTab(4)
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click

        TabControl2.Visible = True
        TabControl2.SelectTab(5)
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click

        TabControl2.Visible = True
        TabControl2.SelectTab(6)
    End Sub

    Private Sub PictureBox1_MouseEnter(sender As Object, e As EventArgs) Handles PictureBox1.MouseEnter
        RectangleShape1.Visible = True
    End Sub

    Private Sub PictureBox1_MouseLeave(sender As Object, e As EventArgs) Handles PictureBox1.MouseLeave
        RectangleShape1.Visible = False
    End Sub


    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        My.Computer.Audio.Play(My.Resources.SA, AudioPlayMode.Background)
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged

    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click

        qnumber = 1
        TextBox4.Text = question(qnumber - 1)
        RadioButton1.Text = ans1(qnumber - 1)
        RadioButton2.Text = ans2(qnumber - 1)
        RadioButton3.Text = ans3(qnumber - 1)
        RadioButton4.Text = ans4(qnumber - 1)
        GroupBox2.Text = "Question " & qnumber & ":"
        Label25.Text = 0
        Label27.Text = 0

        TabControl1.SelectTab(1)
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'show the help page form on screen
        HelpPage.Show()

    End Sub
End Class
